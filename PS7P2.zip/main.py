def compavg(hit,bat) :
  avg = float(hit) / float(bat)

  return avg

name = input("Enter Lastname: ")

hit = float(input("Enter Number of hits: "))

bat = float(input("Enter times at bat: "))

avg = compavg(hit,bat)

print("Batting average of",name,"is",avg)