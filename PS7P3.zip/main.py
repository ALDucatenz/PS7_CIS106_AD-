def compmpg(mile,gal) :
  mpg = float(mile) / float(gal)

  return mpg 

def compcost(gal) :
  cost = float(gal) * 2.50

  return cost

city = input("Enter city: ")

mile = input("Enter miles travelled: ")

gal = input("Enter gallons used: ")

mpg = compmpg(mile,gal)

cost = compcost(gal)

print("City: " , city)
print("Miles travelled: ", mile)
print("Miles per gallon: " , mpg)
print("Cost of gas: $",cost)