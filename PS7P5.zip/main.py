def comptuit(hours,code):
  if code == "I":
    tuition = float(hours) * 250
  elif code == "O":
    tuition = float(hours) * 550
  else:
    tuition = 0
  
  return tuition

name = input("Enter Lastname: ")

hours = input("Enter credit hours: ")

code = input("Enter district code (I or O): ")

tuition = comptuit(hours,code)

print("Name: ", name)
print("Tuition owed: $", tuition)