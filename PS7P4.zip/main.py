def comprate(code):
  if code == "L":
    rate = 25
  elif code == "A":
    rate = 30
  elif code == "J":
    rate = 50
  else:
    rate = 0 
  
  return rate

def compgross(rate,hours):
  gross = float(rate) * float(hours)

  return gross

name = input("Enter last name: ")

code = input("Enter Job code(L,A,J): ")

hours = input("Enter Hours worked: ")

rate = comprate(code)

gross = compgross(rate,hours)

print("Gross pay of", name , "is $", gross)